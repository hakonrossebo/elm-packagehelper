# Package cache

If empty, please use the provided zip archive and extract it here. This is to prevent unneeded full-downloads of all package documentation.